import { useEffect, useState } from 'react';
import '../styles/hero.css';

interface HeroProps {
  title?: string;
  subtitle?: string;
  ctaText?: string;
  ctaLink?: string;
  overlayTitle?: string;
  overlaySubtitle?: string;
  overlayCtaText?: string;
  overlayCtaLink?: string;
  showContent?: boolean;
}

export default function Hero({ 
  title = 'PYRONIX 2K26', 
  subtitle = 'Unleash Your Innovation · March 24, 2026',
  ctaText = '🎯 Get Started',
  ctaLink = '/passes',
  overlayTitle,
  overlaySubtitle,
  overlayCtaText,
  overlayCtaLink,
  showContent = true
}: HeroProps) {
  const heroMode = showContent ? 'full' : 'overlay';
  const [countdown, setCountdown] = useState({
    days: '00',
    hours: '00',
    minutes: '00',
    seconds: '00'
  });

  useEffect(() => {
    const startCountdownTimer = () => {
      const eventDate = new Date(2026, 2, 24, 9, 0, 0).getTime();
      
      const updateCountdown = () => {
        const now = new Date().getTime();
        const timeLeft = eventDate - now;

        if (timeLeft < 0) {
          setCountdown({
            days: '00',
            hours: '00',
            minutes: '00',
            seconds: '00'
          });
          return;
        }

        const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

        setCountdown({
          days: String(days).padStart(2, '0'),
          hours: String(hours).padStart(2, '0'),
          minutes: String(minutes).padStart(2, '0'),
          seconds: String(seconds).padStart(2, '0')
        });
      };

      updateCountdown();
      const interval = setInterval(updateCountdown, 1000);
      return () => clearInterval(interval);
    };

    return startCountdownTimer();
  }, []);

  return (
    <div className="page-hero" data-sign-overlay="true" data-hero-mode={heroMode}>
      {overlayTitle && (
        <div className="hero-overlay" role="region" aria-label={`${overlayTitle} hero`}>
          <h2>{overlayTitle}</h2>
          {overlaySubtitle && <p>{overlaySubtitle}</p>}
          {overlayCtaText && overlayCtaLink && (
            <a className="hero-cta" href={overlayCtaLink}>{overlayCtaText}</a>
          )}
        </div>
      )}
      {showContent && (
        <div className="hero-content">
          <h1 className="hero-title">{title}</h1>
          <p className="hero-tagline">{subtitle}</p>

          <div className="countdown-section">
            <div className="countdown-container">
              <div className="countdown-box">
                <span className="countdown-value">{countdown.days}</span>
                <span className="countdown-label">Days</span>
              </div>
              <span className="countdown-separator">:</span>
              <div className="countdown-box">
                <span className="countdown-value">{countdown.hours}</span>
                <span className="countdown-label">Hours</span>
              </div>
              <span className="countdown-separator">:</span>
              <div className="countdown-box">
                <span className="countdown-value">{countdown.minutes}</span>
                <span className="countdown-label">Minutes</span>
              </div>
              <span className="countdown-separator">:</span>
              <div className="countdown-box">
                <span className="countdown-value">{countdown.seconds}</span>
                <span className="countdown-label">Seconds</span>
              </div>
            </div>
          </div>

          <div className="hero-info">
            <span className="info-badge">📅 March 24, 2026</span>
            <span className="info-badge">📍 Engineering Block, Kongunadu College</span>
          </div>

          <div className="hero-buttons">
            <a href={ctaLink} className="btn btn-primary">{ctaText}</a>
            <a href="/events" className="btn btn-secondary">📊 Explore Events</a>
          </div>
        </div>
      )}
    </div>
  );
}
