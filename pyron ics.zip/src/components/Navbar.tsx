import { useState } from 'react';
import { Link } from 'react-router-dom';
import '../styles/navbar.css';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="navbar">
      <div className="nav-container">
        <Link to="/" className="logo">
          <img src="/logo.png" alt="PYRONIX 2K26" className="logo-img" />
          <span>PYRONIX 2K26</span>
        </Link>
        <button 
          className="nav-toggle"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? '✕' : '☰'}
        </button>
        <ul className={`nav-menu ${isOpen ? 'open' : ''}`}>
          <li><Link to="/" className="nav-link" onClick={() => setIsOpen(false)}>Home</Link></li>
          <li><Link to="/events" className="nav-link" onClick={() => setIsOpen(false)}>Events</Link></li>
          <li><Link to="/fun-events" className="nav-link" onClick={() => setIsOpen(false)}>Fun Events</Link></li>
          <li><Link to="/passes" className="nav-link" onClick={() => setIsOpen(false)}>Passes</Link></li>
          <li><Link to="/coordinators" className="nav-link" onClick={() => setIsOpen(false)}>Coordinators</Link></li>
          <li><Link to="/faq" className="nav-link" onClick={() => setIsOpen(false)}>FAQ</Link></li>
          <li><Link to="/contact" className="nav-link" onClick={() => setIsOpen(false)}>Contact</Link></li>
        </ul>
      </div>
    </nav>
  );
}
