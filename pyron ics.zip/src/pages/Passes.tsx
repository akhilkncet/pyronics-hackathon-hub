import { PASSES } from '../constants';
import { registerForPass } from '../utils';
import '../styles/passes.css';

export default function Passes() {
  return (
    <div className="page-passes">
      <div className="page-hero" data-sign-overlay="true" data-hero-mode="overlay">
        <div className="hero-overlay" role="region" aria-label="Passes hero">
          <h2>Grab Your Pass</h2>
          <p>Choose the pass that fits you — register and secure your spot.</p>
          <button className="hero-cta" onClick={() => window.location.href = '/passes'}>Choose Passes</button>
        </div>
      </div>

      <main className="section registration-dashboard">
        <div className="container">
          <h2 className="section-title" style={{color: '#00f0ff'}}>🎟️ Choose Your Pass & Register</h2>
          <p className="section-subtitle" style={{color: 'rgba(255,255,255,0.85)'}}>Select a pass type and click to complete your registration via Google Form</p>

          <div className="passes-grid">
            {PASSES.map(pass => (
              <div key={pass.id} className={`pass-card-interactive pass-variant-${pass.id.split('t')[1] || 'ruby'}`}>
                <div className="pass-card-top">
                  <div style={{fontSize: '3rem', marginBottom: '0.25rem'}}>{pass.icon}</div>
                  <h3>{pass.name}</h3>
                  <p>{pass.description}</p>
                </div>
                <div className="pass-card-body">
                  <div className="pass-price" style={{color: pass.priceColor}}>{pass.price}</div>
                  <ul className="pass-features">
                    {pass.features.map((feature, i) => (
                      <li key={i}>✅ {feature}</li>
                    ))}
                  </ul>
                  <button 
                    className="pass-cta btn btn-primary"
                    onClick={() => registerForPass(pass.id)}
                    style={{background: pass.gradient, color: '#071017'}}
                  >
                    Register →
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="pass-info-box">
            <p>📢 How it Works: Select a pass → Complete the Google Form to register (no account required)</p>
          </div>
        </div>
      </main>
    </div>
  );
}
