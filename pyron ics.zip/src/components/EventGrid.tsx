import { useEffect, useRef, useState } from 'react';
import { EVENT_DATABASE } from '../constants';

interface EventGridProps {
  filterType?: 'all' | 'tech' | 'non-tech' | 'fun';
  maxCols?: number;
}

export default function EventGrid({ filterType = 'all' }: EventGridProps) {
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<null | { name: string; info: any }>(null);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
          setTimeout(() => {
            entry.target.classList.add('revealed');
          }, index * 80);
        }
      });
    }, { threshold: 0.1 });

    cardsRef.current.forEach(card => {
      if (card) observer.observe(card);
    });

    return () => observer.disconnect();
  }, []);

  const events = Object.entries(EVENT_DATABASE).filter(([_, event]) => {
    if (filterType === 'all') return true;
    return event.type === filterType;
  });

  const groups: Record<string, [string, any][]> = { tech: [], 'non-tech': [], fun: [] };
  events.forEach(([name, info]) => {
    if (info.type === 'tech') groups.tech.push([name, info]);
    else if (info.type === 'non-tech') groups['non-tech'].push([name, info]);
    else if (info.type === 'fun') groups.fun.push([name, info]);
  });

  let cardIndex = 0;

  const renderSection = (title: string, items: [string, any][]) => {
    if (items.length === 0) return null;
    
    return (
      <div key={title} className="event-section">
        <h3 className="event-category">{title} ({items.length})</h3>
        <div className="event-container">
          {items.map(([name, info]) => (
            <div 
              key={name} 
              className={`event-card box-reveal ${info.type}-event`}
              ref={(el) => {
                if (el) cardsRef.current[cardIndex++] = el;
              }}
              onClick={() => setSelectedEvent({ name, info })}
            >
              <div className="event-card-icon">{info.icon || '🔹'}</div>
              <div className="event-name">{name}</div>
              <div className="event-desc">{info.description || ''}</div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="events-wrapper">
        {filterType === 'all' && (
          <>
            {renderSection('⚡ Technical Events', groups.tech)}
            {renderSection('🎭 Non-Technical Events', groups['non-tech'])}
            {renderSection('🎉 Fun Events', groups.fun)}
          </>
        )}
        {filterType === 'tech' && renderSection('⚡ Technical Events', groups.tech)}
        {filterType === 'non-tech' && renderSection('🎭 Non-Technical Events', groups['non-tech'])}
        {filterType === 'fun' && renderSection('🎉 Fun Events', groups.fun)}
      </div>

      {selectedEvent && (
        <div className="event-modal" role="dialog" aria-modal="true">
          <div className="event-modal-backdrop" onClick={() => setSelectedEvent(null)} />
          <div className="event-modal-content">
            <button className="event-modal-close" onClick={() => setSelectedEvent(null)} aria-label="Close">
              ✕
            </button>
            <div className="event-modal-header">
              <div className="event-modal-icon">{selectedEvent.info.icon || '📌'}</div>
              <div>
                <h3>{selectedEvent.name}</h3>
                <p>{selectedEvent.info.description}</p>
              </div>
            </div>
            <p className="event-modal-desc">{selectedEvent.info.fullDescription}</p>

            {Array.isArray(selectedEvent.info.domains) && selectedEvent.info.domains.length > 0 && (
              <div className="event-modal-section">
                <h4>Domains</h4>
                <ul>
                  {selectedEvent.info.domains.map((domain: string) => (
                    <li key={domain}>📄 {domain}</li>
                  ))}
                </ul>
                {selectedEvent.info.notes && (
                  <p className="event-modal-note">🎯 {selectedEvent.info.notes}</p>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
