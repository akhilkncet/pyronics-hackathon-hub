export const SITE_INFO = {
  siteName: 'PYRONIX 2K26',
  eventDate: 'March 24, 2026',
  location: 'Engineering Block, Kongunadu College',
  email: 'kncetsymposiyum@gmail.com',
  phone: '+91 8124076095',
  address: 'KONGUNADU COLLEGE OF ENGINEERING AND TECHNOLOGY, NAMMAKAL - TRICHY MAIN ROAD, THOLURPATTI POST, THOTTIYAM TALUK, TRICHY DISTRICT, TAMIL NADU - 612215'
};

export const FORMS = {
  gold: 'https://forms.gle/YOUR-GOLD-FORM-LINK',
  silver: 'https://forms.gle/YOUR-SILVER-FORM-LINK',
  ticket1: 'https://docs.google.com/forms/d/e/1FAIpQLSetUIFUx0N2P749ThJfWEk-0pIew3Z2G1dtSyDQvBeZ-wWiZQ/viewform?usp=header',
  ticket2: 'https://docs.google.com/forms/d/e/1FAIpQLScxpFRL_cZxWneMBBsihmr4iNhLoaYzgrYqilkrlFvVVoyBRw/viewform?usp=header',
  ticket3: 'https://docs.google.com/forms/d/e/1FAIpQLScFOqg3mPAzCukJVSE4XGlu-gAz8cA4IRa77uDa9qedbvEAtg/viewform?usp=header'
};

export const EVENT_DATABASE = {
  // Technical Events
  'Paper Presentation': {
    icon: '📄',
    description: 'Ignite your ideas and showcase innovation at our premier paper presentation event.',
    fullDescription: 'Ignite your ideas and showcase innovation at our premier paper presentation event. Dive into cutting-edge discussions on engineering breakthroughs, from sustainable materials to AI-driven solutions. Present your research and network with peers and experts.',
    domains: [
      'Cloud Computing and Visualization',
      'Cyber-security & Blockchain',
      'AI in Health Care & Medtech',
      'Advanced Manufacturing',
      'Smart Cities & Infrastructure',
      'Bio-Mechanics & Prosthetics, Biomimicry',
      'Sustainable Energy Systems',
      'Emerging Technologies in Smart Farming Systems'
    ],
    notes: 'Participants can choose their domains irrespective of their own departments.',
    teamSize: 'Individual or Team (Max 3)',
    duration: '10-15 mins per team',
    prize: 'Certificates + Cash prizes',
    cost: 'Included in pass',
    type: 'tech'
  },
  'CUEX': {
    icon: '💻',
    description: 'A high-octane quiz-style showdown focused on artificial intelligence concepts.',
    fullDescription: 'A high-octane quiz-style showdown focused on artificial intelligence concepts, designed to buzz answer rapid-fire questions testing AI fundamentals, machine learning algorithms, neural networks, ethical dilemmas, and real-world applications.',
    teamSize: 'Max 2 members',
    duration: '60-90 mins',
    prize: 'Certificates + Prizes',
    cost: 'Included in pass',
    type: 'tech'
  },
  'Tech Trek': {
    icon: '🧭',
    description: 'A tech-oriented event to give the desired output via coding.',
    fullDescription: 'A tech-oriented event with the most prominent being to give out the desired output via coding.',
    teamSize: 'Max 3 members',
    duration: '90 mins',
    prize: 'Certificates',
    cost: 'Included in pass',
    type: 'tech'
  },
  'Error 404': {
    icon: '🛠️',
    description: 'Harness innovative solutions to crack long-standing challenges.',
    fullDescription: 'Harnessing innovative solutions to crack long-standing unsolved challenges from the past, paving the way for transformative advancements that deliver enduring benefits to future generations.',
    teamSize: 'Individual or Team (Max 2)',
    duration: '120 mins',
    prize: 'Certificates + Prizes',
    cost: 'Included in pass',
    type: 'tech'
  },
  // Non-Technical Events
  'SnapStreak': {
    icon: '📸',
    description: 'Capture the campus canvas with creative visuals and technical precision.',
    fullDescription: 'Capture the campus canvas! Unleash your creative eye to transform the campus scenes into stunning visuals, blending technical precision with artistic flair using your phones, cameras and other contrivance.',
    teamSize: 'Individual',
    duration: 'Ongoing',
    prize: 'Certificates',
    cost: 'Included in pass',
    type: 'non-tech'
  },
  'Vibe Check': {
    icon: '🎶',
    description: 'A lively, interactive icebreaker to boost the crowd energy.',
    fullDescription: 'A lively, interactive icebreaker or talent showcase where participants perform short, spontaneous acts—like dances, skits, songs, or comedy bits—to check and boost the crowd’s energy and mood.',
    teamSize: 'Up to 5',
    duration: 'Varies',
    prize: 'Certificates + Prizes',
    cost: 'Included in pass',
    type: 'non-tech'
  },
  'IPL Auction': {
    icon: '🏏',
    description: 'Thrilling, strategy-packed event mimicking real IPL player bids.',
    fullDescription: 'A thrilling, strategy-packed event mimicking real IPL player bids. Teams act as franchise owners, bidding virtual crores for players within a budget, blending IPL knowledge, negotiation, and tactics.',
    teamSize: 'Teams of 2-3',
    duration: '45 mins',
    prize: 'Certificates',
    cost: 'Included in pass',
    type: 'non-tech'
  },
  'Tech Part Hunt': {
    icon: '🔎',
    description: 'Race to decode riddles, identify components, and solve circuit puzzles.',
    fullDescription: 'Ultimate engineering adventure race against the clock to decode riddles, identify mysterious components, solve circuit puzzles, and hunt down hidden tech parts across clues—testing electronics, circuits, C programming and logic.',
    teamSize: 'Up to 3',
    duration: '60 mins',
    prize: 'Certificates',
    cost: 'Included in pass',
    type: 'non-tech'
  },
  // Fun Events
  'DJ Session': {
    icon: '🎧',
    description: 'Live DJ performances and music showcase.',
    fullDescription: 'DJ Session: Live DJ performances featuring guest DJs — a music showcase (non-party event).',
    teamSize: 'N/A',
    duration: 'Evening',
    prize: 'Event Access',
    cost: 'Included in pass',
    type: 'fun'
  },
  'Treasure Hunt': {
    icon: '🗺️',
    description: 'Campus-wide treasure hunt with clues and puzzles.',
    fullDescription: 'Treasure Hunt: Solve clues and race to find hidden items across the venue.',
    teamSize: 'Teams of up to 4',
    duration: '90 mins',
    prize: 'Gifts + Certificates',
    cost: 'Included in pass',
    type: 'fun'
  },
  'Lucky Draw': {
    icon: '🎟️',
    description: 'Lucky draw for attendees with exciting prizes.',
    fullDescription: 'Lucky Draw: Registered participants are eligible for random prize draws during the event.',
    teamSize: 'N/A',
    duration: 'During event',
    prize: 'Merch & Gifts',
    cost: 'Included in pass',
    type: 'fun'
  },
  'Word Hunt': {
    icon: '🔤',
    description: 'Quick puzzle game testing vocabulary and speed.',
    fullDescription: 'Word Hunt: Timed rounds where participants find words from given letters or clues.',
    teamSize: 'Individual or Teams',
    duration: '30 mins',
    prize: 'Certificates',
    cost: 'Included in pass',
    type: 'fun'
  },
  'Minute To Win': {
    icon: '⏱️',
    description: 'Fast-paced one-minute challenge games.',
    fullDescription: 'Minute To Win: Series of quick challenges where participants complete tasks in 60 seconds.',
    teamSize: 'Individual or small teams',
    duration: 'Multiple short rounds',
    prize: 'Prizes & Certificates',
    cost: 'Included in pass',
    type: 'fun'
  }
};

export const PASSES = [
  {
    id: 'ticket1',
    name: 'RUBY',
    icon: '🎫',
    description: '1 Tech + 1 Non-Tech',
    price: '₹250',
    priceColor: '#ffdfe6',
    features: [
      'Participate in 1 technical event',
      'Participate in 1 non-technical event'
    ],
    gradient: 'linear-gradient(90deg,#ff4d89,#ff9ab2)'
  },
  {
    id: 'ticket2',
    name: 'EMERALD',
    icon: '🎫',
    description: '1 Tech + 2 Non-Tech',
    price: '₹300',
    priceColor: '#e6fbf6',
    features: [
      '1 technical event',
      '2 non-technical events'
    ],
    gradient: 'linear-gradient(90deg,#2ebf9a,#68f1d1)'
  },
  {
    id: 'ticket3',
    name: 'TOPAZ',
    icon: '🎫',
    description: '2 Tech + 2 Non-Tech',
    price: '₹350',
    priceColor: '#eaffea',
    features: [
      '2 technical events',
      '2 non-technical events'
    ],
    gradient: 'linear-gradient(90deg,#6be37a,#d3ffb0)'
  }
];
